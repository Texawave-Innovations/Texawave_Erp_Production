---
name: Restrained Enterprise ERP
colors:
  surface: '#eeffde'
  surface-dim: '#abeb86'
  surface-bright: '#eeffde'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#d9ffbf'
  surface-container: '#c1ff9c'
  surface-container-high: '#b9fa93'
  surface-container-highest: '#b3f48e'
  on-surface: '#082100'
  on-surface-variant: '#3d4a3a'
  inverse-surface: '#123800'
  inverse-on-surface: '#cdffae'
  outline: '#6d7b68'
  outline-variant: '#bccbb5'
  surface-tint: '#006e19'
  primary: '#006e19'
  on-primary: '#ffffff'
  primary-container: '#06ba32'
  on-primary-container: '#00410b'
  inverse-primary: '#4be256'
  secondary: '#4e6700'
  on-secondary: '#ffffff'
  secondary-container: '#c3ef4b'
  on-secondary-container: '#526b00'
  tertiary: '#1b6d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#33b900'
  on-tertiary-container: '#0c4100'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#71ff73'
  primary-fixed-dim: '#4be256'
  on-primary-fixed: '#002203'
  on-primary-fixed-variant: '#005310'
  secondary-fixed: '#c6f24e'
  secondary-fixed-dim: '#abd532'
  on-secondary-fixed: '#151f00'
  on-secondary-fixed-variant: '#3a4d00'
  tertiary-fixed: '#7aff53'
  tertiary-fixed-dim: '#40e400'
  on-tertiary-fixed: '#042100'
  on-tertiary-fixed-variant: '#125200'
  background: '#eeffde'
  on-background: '#082100'
  surface-variant: '#b3f48e'
typography:
  display-lg:
    fontFamily: Nunito Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Nunito Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Nunito Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Nunito Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Nunito Sans
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-md:
    fontFamily: Nunito Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Nunito Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-dense: 0.5rem
  margin: 1.5rem
  margin-compact: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system targets enterprise operators, financial controllers, operational planners, and organizational executives who spend hours navigating high-density data, ledger workflows, and resource allocation matrices. The brand personality is disciplined, intellectual, deliberate, and understated. It avoids decorative noise, performative embellishments, and transient software fads, prioritizing spatial composure, rigorous order, and ergonomic comfort over extended operational sessions.

The design movement combines **Corporate Modern** with **Content-Driven Editorial Minimalism**. Visual gravity is achieved through subtle value shifts, precise grid boundaries, and classic typographic proportions. The environment evokes the calm efficiency of archival ledgers, architectural drafting documents, and institutional records, reframed as a responsive digital work surface.

## Colors

The palette is rooted in a vibrant, content-informed botanical spectrum: energetic bright green, vibrant lime-moss, and crisp digital neon green, underpinned by balanced mineral neutrals.

- **Primary (`#06ba32`)**: A vivid, high-clarity green used for key interactive triggers, primary navigation anchors, critical callouts, and dominant status indicators.
- **Secondary (`#b0db38`)**: A bright lime-moss green designed for secondary structural elements, column groups, active tab underlines, and metric highlights.
- **Tertiary (`#43ed00`)**: A clean digital green-cyan accent applied to non-critical badge fills, low-emphasis highlights, and distinct data groupings.
- **Neutral (`#3a721c`)**: A balanced, desaturated gray-green serving as the basis for body copy, quiet icons, tabular headers, and boundary rules.

### Surface Tones & Tokens
- **Canvas Base**: `#f5fbf5` — a faintly tinted warm-white surface that mitigates glare during intensive sessions.
- **Surface Level 1 (Panels & Sheets)**: `#ffffff` — clean contrast against the canvas for cards, data tables, and input docks.
- **Surface Level 2 (Docked Bars & Field Insets)**: `#eff5f0` — muted green-tinted gray for nested regions, table headers, and disabled fields.
- **Border / Hairline Muted**: `#c0c8c4` — a crisp, quiet edge that delineates cells and layout frames without visually slicing the interface.
- **Border / Structural Active**: `#717975` — applied to active focus frames, card separators, and pinned table column borders.
- **Semantic Accents**: Error states rely on a restrained terracotta (`#ba1a1a`), warnings employ amber brass, and confirmations utilize clear green.

## Typography

Typography delivers architectural discipline and rapid horizontal scanning across ledger views. Nunito Sans is chosen for its clean proportions, uniform horizontal rhythm, and balanced modernist geometry that balances editorial quality with mechanical rigor.

- **Tabular Numerics & Font Features**: All metric values, ledger amounts, dates, and identifier rows must render with OpenType `tnum` (tabular numbers) and `cv01`/`ss01` alternate glyph configurations enabled, ensuring numeric alignment across millions of rows.
- **Monospaced Data**: `JetBrains Mono` handles system logs, ledger journal IDs, account routing strings, and hex values where absolute character width uniformity is required.
- **Hierarchy and Rhythm**: Leading values are kept snug (1.25–1.38 ratio) to permit high data density without collapsing ascenders and descenders. Uppercase labels are tracked out cleanly (`0.03em` to `0.04em`) to establish clear hierarchy above data clusters.

## Layout & Spacing

The structural framework is an adaptive 12-column fluid grid calibrated for enterprise workspaces, financial tables, and operational Gantt charts. The layout embraces structural alignment, dense vertical rhythm, and minimal dead space.

- **Desktop (1280px+)**: 12-column fluid grid, `1.5rem` outside margin, `1rem` column gutters. In multi-ledger financial consoles, gutters drop to `0.5rem` (`gutter-dense`) to maximize usable horizontal canvas space.
- **Tablet / Operational Console (768px – 1279px)**: 8-column layout with fixed collapsable utility drawers, `1rem` margin, and `0.75rem` column gutters.
- **Mobile (Below 768px)**: 4-column layout, `1rem` margin, and `0.5rem` gutters. Tables reflow into structured key-value audit cards.
- **Rhythm**: All spacing parameters increment predictably along a 4px/8px baseline grid. Structural components prefer `space-sm` (`8px`) and `space-md` (`12px`) for interior element separation, preserving compact operational density across viewports.

## Elevation & Depth

Visual hierarchy is communicated through **tonal layering and low-contrast outlines**, eliminating aggressive drop shadows that disrupt line-by-line reading.

- **Level 0 (Workspace Canvas)**: `#f5fbf5`. Ground plane for entire viewport.
- **Level 1 (Work Surface & Paneling)**: `#ffffff` framed by a 1px border of `#c0c8c4`. No drop shadow. Depth is communicated strictly through surface brightness difference against Level 0.
- **Level 2 (Dropdowns, Popovers, Flyout Contexts)**: `#ffffff` framed by a 1px border of `#717975` with an ambient, diffused shadow: `0 4px 16px -4px rgba(6, 186, 50, 0.08)`.
- **Level 3 (Modal Dialogues & Audit Overlays)**: `#ffffff` bounded by a 1px `#b0db38` stroke and a resting shadow: `0 12px 32px -8px rgba(6, 186, 50, 0.14)`. Backdrop is an opaque slate wash: `rgba(57, 114, 28, 0.35)`.
- **Active Grid Row Pinning**: Sticky headers and frozen data columns utilize a 1px vertical border in `#717975` with a subtle edge blur (`4px`) to establish layering without elevation jumps.

## Shapes

The design system uses a **Rounded (`2`)** shape language (`0.5rem` / 8px base radius). This corner radius softens functional corners while maintaining strict tabular grid geometry.

- **Inputs, Buttons, Cells, and Standard Elements**: `0.5rem` (8px). Matches the layout rhythm and maintains alignment in stacked input grids.
- **Cards, Paneling, Sheets, and Modals (`rounded-lg`)**: `1rem` (16px). Delivers an approachable, orderly boundary for major page modules.
- **Status Pills and Counter Indicators**: `0.5rem` (8px) with inner horizontal padding rather than circular pill shapes, reinforcing the architectural aesthetic.

## Components

### Buttons
- **Primary**: Solid background of `#06ba32`, crisp white text, `0.5rem` border radius, padding `0.375rem 0.875rem`. Hover state transitions to `#05a22c`. Active state: `#048b25`. Focused: outline `2px solid #b0db38` with `2px` offset.
- **Secondary (Outlined)**: `#ffffff` surface, 1px border `#717975`, text color `#06ba32`. Hover transitions to `#eff5f0`.
- **Tertiary / Ghost**: Transparent surface, `#06ba32` text. Hover background `#eff5f0`.
- **Destructive**: Subdued background `#fdf2f2`, 1px border `#f2b8b5`, text `#ba1a1a`. Hover: `#ba1a1a` with `#ffffff` text.

### Data Tables (ERP Core)
- **Header Cells**: Height `32px`, background `#eff5f0`, text `label-sm` (`#3a721c`), uppercase with `0.04em` tracking. 1px bottom border `#c0c8c4`.
- **Data Rows**: Standard row height `36px`; dense mode `28px`. Bottom border 1px `#c0c8c4`. Numeric cells set in `Nunito Sans` with `font-variant-numeric: tabular-nums` or `JetBrains Mono` for ID columns, right-aligned.
- **Selected Row**: Background `#e4f2e5` with a 2px solid `#06ba32` left inset indicator.

### Input Fields & Controls
- **Text & Numeric Inputs**: Height `32px` (dense: `28px`), background `#ffffff`, 1px border `#c0c8c4`, typography `body-md`. Focus: border `#06ba32` with a 1px inner glow `rgba(6, 186, 50, 0.15)`.
- **Checkboxes & Radios**: 14px square/circle, border 1.5px `#b0db38`. Selected state: `#06ba32` fill with sharp white indicator.
- **Filter Chips**: Height `24px`, background `#eff5f0`, border 1px `#c0c8c4`, font `label-sm`. Active filter: background `#d3ecd5`, border `#43ed00`, text `#06ba32`.

### Cards & Container Panels
- Base background `#ffffff`, border 1px `#c0c8c4`, border radius `1rem`. Card headers feature a `36px` height boundary with a subtle bottom divider and `title-md` typography.

### Status Indicators & Badges
- **Active / Settled**: Background `#d3ecd5`, text `#b0db38`, border 1px `#86cb89`.
- **Pending / In Review**: Background `#fff8e1`, text `#8d6b00`, border 1px `#ffecb3`.
- **Discrepancy / Alert**: Background `#fdf2f2`, text `#ba1a1a`, border 1px `#f2b8b5`.
- **Archived / Dormant**: Background `#eff5f0`, text `#3a721c`, border 1px `#c0c8c4`.

### Operational Additions
- **KPI Summary Ribbon**: Horizontal metrics band utilizing `#f5fbf5` backing, with dividing borders in `#c0c8c4` and metric values set in `display-lg` (`#06ba32`).
- **Audit Timeline Inset**: Vertical progression line in 1px `#c0c8c4` with node dots in `#b0db38` indicating transaction ledger history.